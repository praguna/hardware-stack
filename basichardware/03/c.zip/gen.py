s = "Register(in=in, load=load, out=r{i});"
for i in range(0,16):
    print(s.format(i=i))



 